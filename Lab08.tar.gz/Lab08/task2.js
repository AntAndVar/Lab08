/* Task2.js - Add your Java Script Code Here */
function changeVal(place) {
    var p = document.getElementById("mydata");
    p.innerHTML = "Value = " + place;
}
