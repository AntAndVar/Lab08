/* Task1.js - Add your Java Script Code Here */
function myFunction()
{
  var p = document.getElementById("mydata");
  var holder = Math.random();
  if (holder <= 0.5) {
    p.innerHTML = "heads";
  } else {
    p.innerHTML = "tails";
  }
  // set p.innerHTML equal to heads or tails

}
